const express=require('express');
const router=express.Router();
const jwt=require('jsonwebtoken')
const PROdata=require('./BACKEND/src/models/PROdata');
const SEntrydata=require('./BACKEND/src/models/SEntrydata')


router.get('/productslist',(req,res)=>{
    
    console.log("viewlist")

    PROdata.find().then((product)=>{res.send(product)});
   
});


router.post('/uplist',(req,res)=>{

    console.log("uplist")
    id=req.body.ID.id;
    console.log(id);
    PROdata.findById({_id:id}).then((product)=>{res.send(product)});

})



router.post('/insert',(req,res)=>{
    
    console.log("product added")
    console.log(req.body);  
    var product={

        productId:req.body.product.productId,
        productName:req.body.product.productName,
        productCode:req.body.product.productCode,
        price:req.body.product.price,
        starRating:req.body.product.starRating,
        imageUrl:req.body.product.imageUrl,
        releaseDate:req.body.product.releaseDate,
        description:req.body.product.description,

    }

    var product=new PROdata(product);
    product.save();

});


router.post("/add",function(req,res){
 
  console.log("user added")
  console.log(req.body)

    var newuser={

        email:req.body.userinfo.email,
      
        password:req.body.userinfo.password,
    }

    var newuser= new SEntrydata(newuser);
    newuser.save();
   res.send(newuser)
});



router.post('/check',  function(req, res){

  console.log("login")
  console.log(req.body)

    var l = {
          email:req.body.newlog.email,
         password:req.body.newlog.password
     }
     
     
     
     SEntrydata.findOne(l).then(function (data){
         if(data!=null){
               console.log("found")
               
               let payload={subject:data._id}
               let token =jwt.sign(payload,"secretkey")
               res.status(200).send({token})

             }
             
             else
              {
              console.log('not found')};
             
              })
 
    });
 


router.post('/delete',(req,res)=>{
    console.log('delete');
    id=req.body.id;
    console.log(id)
    PROdata.findByIdAndDelete({_id:id}).then(()=>{console.log("Deleted Successfully");
    PROdata.find().then((product)=>{res.send(product);})})
})


router.post('/update',(req,res)=>{
    
    id=req.body.ID.id;
    console.log("update");
    console.log(id);
    
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods: GET, POST,PUT, PATCH, DELETE, OPTIONS");
  
    PROdata.findByIdAndUpdate({_id:id},{productId:req.body.product.productId,
        productName:req.body.product.productName,productCode:req.body.product.productCode,
        price:req.body.product.price,
        starRating:req.body.product.starRating,
        
        imageUrl:req.body.product.imageUrl,     
        releaseDate:req.body.product.releaseDate, 
        description:req.body.product.description},(err,doc)=>{if(err)console.log(err)} )
    

   
    })



module.exports=router;