export class SignModel{
    constructor(
        
        public email:String,
        public password:String
       
        
    ){}

}