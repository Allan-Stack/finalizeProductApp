import { Component, OnInit } from '@angular/core';
import{ProductModel} from './product.model';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  products:ProductModel[];
  imageWidth :number=50;
  imageMargin :number=2;
  ShowImage: boolean=false;
  constructor(private productService:ProductService) { }

  toogle():void{
    this.ShowImage=!this.ShowImage;
  }

  ngOnInit(): void {
    this.productService.getProducts().subscribe((data)=>{this.products=JSON.parse(JSON.stringify(data)); })
    
  }

  delpro(_id):void{   if(confirm("Are you sure that u want to delete this item ?")==true){
    this.productService.deletePro(_id).subscribe((data)=>{this.products=JSON.parse(JSON.stringify(data))});
    }}


}
