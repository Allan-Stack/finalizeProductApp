import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http:HttpClient) { }

  newlog(loguser){

    console.log(loguser)
    return this.http.post("http://localhost:12000/api/check",{"newlog":loguser})
   

  }

    
  newUser(user){
   
    console.log(user)
    return this.http.post("http://localhost:12000/api/add",{"userinfo":user})
   
  }
  
 loggedIn(){

   return !! localStorage.getItem('token')
 
  }
  
  }
